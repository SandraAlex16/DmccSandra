/* tslint:disable */
require("./UptownOffersListingWebPart.module.css");
const styles = {
  uptownOffersListing: 'uptownOffersListing_44388112',
  teams: 'teams_44388112',
  welcome: 'welcome_44388112',
  welcomeImage: 'welcomeImage_44388112',
  links: 'links_44388112'
};

export default styles;
/* tslint:enable */