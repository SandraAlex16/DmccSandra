/* tslint:disable */
require("./JltOffersListingWebPart.module.css");
const styles = {
  jltOffersListing: 'jltOffersListing_20db9125',
  teams: 'teams_20db9125',
  welcome: 'welcome_20db9125',
  welcomeImage: 'welcomeImage_20db9125',
  links: 'links_20db9125'
};

export default styles;
/* tslint:enable */