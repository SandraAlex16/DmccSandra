/* tslint:disable */
require("./HomeVideoGalleryWebPart.module.css");
const styles = {
  homeVideoGallery: 'homeVideoGallery_41775ec1',
  teams: 'teams_41775ec1',
  welcome: 'welcome_41775ec1',
  welcomeImage: 'welcomeImage_41775ec1',
  links: 'links_41775ec1'
};

export default styles;
/* tslint:enable */